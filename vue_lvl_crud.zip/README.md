# CRUD_vue_laravel
 
